package models;

public class NavalBattle {

	public char[][] userDashboard;
	public char[][] cpuDashboard;
	public char[][] cpuDashboardToPlayer;
	public static final int MIN_COLUMNS = 4;
	public static final int MIN_ROWS = 4;
	public static final int MIN_SHIPS = 4;
	private int attemps;

	public boolean Start(int rows, int columns) {
		if (rows >= MIN_ROWS && columns >= MIN_COLUMNS) {
			initialize(rows, columns);
			return true;
		}
		return false;
	}

	private void initialize(int rows, int colums) {
		userDashboard = new char[rows][colums];
		cpuDashboard = userDashboard;
		cpuDashboardToPlayer = userDashboard;
		for (int i = 0; i < userDashboard.length; i++) {
			for (int j = 0; j < userDashboard[0].length; j++) {
				userDashboard[i][j] = 'M';
				cpuDashboard[i][j] = 'M';
				cpuDashboardToPlayer[i][j] = 'M';
			}
		}
		attemps = 5;
		generateShips();
		generateLargeShipHorinzontal();
		generateLargeShipHorinzontalCpu();
		generateLargeShipVertical();
		generateLargeShipVerticalCpu();
	}

	private void generateShips() {
		int numberShip = userDashboard.length * userDashboard[0].length / MIN_SHIPS;
		for (int i = 0; i < numberShip; i++) {
			userDashboard[(int) Math.random() * userDashboard.length][(int) Math.random()
					* userDashboard[0].length] = 'B';
			cpuDashboard[(int) Math.random() * cpuDashboard.length][(int) Math.random() * cpuDashboard[0].length] = 'B';
		}
	}

	private void generateLargeShipHorinzontal() {
		int row = (int) Math.random() * userDashboard.length;
		int column = (int) Math.random() * userDashboard[0].length;
		if (column >= 1 && column + 2 <= userDashboard[0].length) {
			userDashboard[row][column - 1] = 'B';
			userDashboard[row][column] = 'B';
			userDashboard[row][column + 1] = 'B';
			userDashboard[row][column + 2] = 'B';
		} else {
			generateLargeShipHorinzontal();
		}
		return;
	}

	private void generateLargeShipHorinzontalCpu() {
		int row = (int) Math.random() * cpuDashboard.length;
		int column = (int) Math.random() * cpuDashboard[0].length;
		if (column >= 2 && column + 2 <= cpuDashboard[0].length) {
			cpuDashboard[row][column - 1] = 'B';
			cpuDashboard[row][column] = 'B';
			cpuDashboard[row][column + 1] = 'B';
			cpuDashboard[row][column + 2] = 'B';
		} else {
			generateLargeShipHorinzontalCpu();
		}
		return;
	}

	private void generateLargeShipVertical() {
		int row = (int) Math.random() * userDashboard.length;
		int column = (int) Math.random() * userDashboard[0].length;
		if (row >= 2 && row + 2 <= userDashboard.length) {
			userDashboard[row - 1][column] = 'B';
			userDashboard[row][column] = 'B';
			userDashboard[row + 1][column] = 'B';
			userDashboard[row + 2][column] = 'B';
		} else {
			generateLargeShipVertical();
		}
		return;
	}

	private void generateLargeShipVerticalCpu() {
		int row = (int) Math.random() * cpuDashboard.length;
		int column = (int) Math.random() * cpuDashboard[0].length;
		if (row >= 2 && row + 2 <= cpuDashboard.length) {
			cpuDashboard[row - 1][column] = 'B';
			cpuDashboard[row][column] = 'B';
			cpuDashboard[row + 1][column] = 'B';
			cpuDashboard[row + 2][column] = 'B';
		} else {
			generateLargeShipVerticalCpu();
		}
		return;
	}

	private void attackUser() {
		int row = (int) Math.random() * cpuDashboard.length;
		int column = (int) Math.random() * cpuDashboard[0].length;
		if (userDashboard[row][column] == 'B') {
			userDashboard[row][column] = 'X';
			attackUser();
		} else {
			userDashboard[row][column] = 'F';
		}
	}

	public boolean checkCpuDashboard() {
		for (int i = 0; i < cpuDashboard.length; i++) {
			for (int j = 0; j < cpuDashboard.length; j++) {
				if (cpuDashboard[i][j] == 'B') {
					return true;
				}
			}
		}
		return false;
	}

	public boolean checkUserDashboard() {
		for (int i = 0; i < userDashboard.length; i++) {
			for (int j = 0; j < userDashboard.length; j++) {
				if (userDashboard[i][j] == 'B') {
					return true;
				}
			}
		}
		return false;
	}

	public boolean attackCpu(int row, int column) {
		if (cpuDashboard[row][column] == 'B') {
			cpuDashboard[row][column] = 'X';
			cpuDashboardToPlayer[row][column] = 'X';
			attemps++;
			return true;
		} else if (cpuDashboard[row][column] == 'M') {
			cpuDashboardToPlayer[row][column] = 'F';
			attemps--;
			return false;
		} else {
			return false;
		}
	}
}
