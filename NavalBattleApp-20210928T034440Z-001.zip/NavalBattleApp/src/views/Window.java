package views;

public class Window {

}
